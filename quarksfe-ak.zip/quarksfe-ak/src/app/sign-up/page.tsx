export default function SignUpPage() {
  return <div>Sign-Up Page</div>;
}